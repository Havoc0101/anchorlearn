// Run with Playwright installed. Network is mocked; no model calls or real tasks.
const {chromium}=require('playwright');
const fs=require('node:fs');
const assert=require('node:assert/strict');
(async()=>{
const browser=await chromium.launch({headless:true,channel:process.env.TEST_BROWSER_CHANNEL||'chrome'});
try{
 const page=await browser.newPage();let saved=[],attempts=[],fail=true;
 const task={title:'提交报告',due_date:null,requirements:'PDF，800字',first_step:'打开文档',source_quote:'交报告。'};
 let result={reading_card:'报告需要提交。',key_points:['重点1','重点2','重点3','重点4'],tasks:[task],clarifications:[]};
 await page.route('http://127.0.0.1:8765/**',async route=>{
  const path=new URL(route.request().url()).pathname;
  if(path==='/')return route.fulfill({contentType:'text/html',body:fs.readFileSync('index.html','utf8')});
  if(path==='/api/analyze')return route.fulfill({json:result});
  if(path==='/api/tasks')return route.fulfill({json:{tasks:saved}});
  if(path==='/api/tasks/confirm'){
   const body=route.request().postDataJSON();attempts.push(body);
   if(!saved.length)saved=body.tasks.map(t=>({...t,id:'test-id'}));
   if(fail){fail=false;return route.abort();}
   return route.fulfill({json:{tasks:saved}});
  }
  throw Error('Unexpected request '+path);
 });
 await page.goto('http://127.0.0.1:8765/');await page.locator('#text').fill('交报告。');await page.locator('#run').click();
 await page.getByLabel('要做什么',{exact:true}).fill('提交修改后的报告');
 await page.getByRole('button',{name:'确认并保存这件事',exact:true}).click();
 await page.getByRole('button',{name:'重试保存（不会重复添加）',exact:true}).click();
 await page.getByRole('button',{name:'已保存',exact:true}).waitFor();
 assert.deepEqual(attempts[0],attempts[1]);assert.equal(saved.length,1);assert.equal(saved[0].requirements,'PDF，800字');
 await page.reload();await page.locator('#saved h3').waitFor();assert.equal(await page.locator('#saved h3').textContent(),'提交修改后的报告');
 result={reading_card:'这段在介绍访谈。',key_points:['开放式提问'],tasks:[],clarifications:[]};
 await page.locator('#text').fill('访谈。');await page.locator('#run').click();await page.getByRole('heading',{name:'这次只需要了解',exact:true}).waitFor();assert.equal(await page.locator('#cards form').count(),0);
 result={reading_card:'不同组要求不同。',key_points:['第二组提交'],tasks:[],clarifications:[{question:'你属于哪组？',source_quote:'第二组交。'}]};
 await page.locator('#run').click();await page.getByText('你属于哪组？',{exact:true}).waitFor();assert.equal(await page.locator('#cards form').count(),0);
 console.log('PASS: edit/save/retry/reload/no-task/clarification');
}finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
