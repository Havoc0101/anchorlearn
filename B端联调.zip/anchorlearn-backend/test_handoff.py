import io
import json
import tempfile
import unittest
from pathlib import Path
from email.message import Message
from unittest.mock import patch
import server
import tasks

class HandoffCheck(unittest.TestCase):
    def call(self, method, path, data=None, host='127.0.0.1:8765', origin='http://127.0.0.1:8765'):
        handler = object.__new__(server.Handler)
        handler.path = path
        handler.headers = Message()
        for key,value in [('Host',host),('Origin',origin),('Content-Type','application/json')]: handler.headers[key]=value
        body=json.dumps(data).encode()
        handler.headers['Content-Length']=str(len(body))
        handler.rfile=io.BytesIO(body)
        result=[]
        handler.send=lambda *args:result.append(args)
        getattr(handler,'do_'+method)()
        return result[0]

    def test_static_and_api_security(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder); public=root/'dist';public.mkdir();(public/'assets').mkdir()
            (public/'index.html').write_text('<h1>App</h1>');(public/'assets/app.js').write_text('console.log(1)')
            (root/'secret.js').write_text('secret');(public/'escape.js').symlink_to(root/'secret.js')
            (public/'tasks.db').write_text('private')
            with patch.object(server,'FRONTEND_DIR',public.resolve()),patch.object(tasks,'DB_PATH',root/'tasks.db'):
                for path in ['/', '/assets/app.js?v=1']:
                    self.assertEqual(self.call('GET',path)[0],200)
                for path in ['/../secret.js','/%2e%2e/secret.js','/escape.js','/tasks.db','/.env','/server.py']:
                    self.assertEqual(self.call('GET',path)[0],404)
                self.assertEqual(self.call('GET','/',host='evil.example')[0],403)
                task={'title':'交报告','first_step':'打开文档','source_quote':'交报告。','due_date':None,'requirements':'PDF'}
                data={'request_id':'handoff-test-001','confirmed':True,'tasks':[task]}
                self.assertEqual(self.call('POST','/api/tasks/confirm',data,origin='http://evil.example')[0],403)
                first=self.call('POST','/api/tasks/confirm',data)
                self.assertEqual(first[0],200)
                self.assertEqual(first,self.call('POST','/api/tasks/confirm',data))
                self.assertEqual(self.call('GET','/api/tasks')[1]['tasks'],first[1]['tasks'])
                data['tasks'][0]['title']='不同内容'
                self.assertEqual(self.call('POST','/api/tasks/confirm',data)[0],409)

if __name__=='__main__':unittest.main()
